m = int(input('Nhập vào số nguyên dương m: '))
n = int(input('Nhập vào số nguyên dương n: '))
print(m,'chia cho',n,'có phần nguyên là',m//n)
print(m,'chia cho',n,'có phần nguyên là',m%n)