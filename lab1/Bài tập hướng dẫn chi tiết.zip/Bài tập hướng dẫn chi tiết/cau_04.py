c = float(input('Mời nhập nhiệt độ C: '))
k = c + 273.15
print(c, 'độ C tương ứng với', k, 'nhiệt độ K')