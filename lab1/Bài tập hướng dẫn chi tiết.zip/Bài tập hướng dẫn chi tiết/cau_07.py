import math
h = float(input('Nhập độ cao của vật: '))
g = 9.8
v = math.sqrt(2*g*h)
print(f'Vận tốc của vật rơi là {v:.2f}')
