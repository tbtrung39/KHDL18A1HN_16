r = float(input('Nhập số đo bán kính R: '))
s = 3.14*r*r
cv=3.14*2*r
print('Diện tích của hình tròn là%0.2f'%s)
print('Chu vi của hình tròn là: %0.2f'%cv)