retained = 100 
interest = 0.15 
result = retained * (1 + interest) ** 10
print(result)