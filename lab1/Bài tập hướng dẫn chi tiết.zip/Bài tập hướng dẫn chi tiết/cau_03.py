so_nhi_phan = input('Nhập số nhị phân: ')
print('Số nhị phân', so_nhi_phan, 'có giá trị tương ứng trong hệ 10 là:', int(so_nhi_phan, 2))