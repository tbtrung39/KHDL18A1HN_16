a = float(input('Nhập số đo đáy lớn: '))
b = float(input('Nhập số đo đáy bé: '))
h = float(input('Nhập số đo chiều cao: '))
s = (a + b)*h/2
print('Diện tích của hình thang là',s)